from django.apps import AppConfig


class PortfoliooConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'portfolioo'
