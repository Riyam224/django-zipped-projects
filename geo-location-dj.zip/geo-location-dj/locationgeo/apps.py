from django.apps import AppConfig


class LocationgeoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'locationgeo'
