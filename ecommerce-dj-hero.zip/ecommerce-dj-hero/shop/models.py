from django.db import models

# Create your models here.
from django.utils.text import slugify
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _



class Product(models.Model):
    title = models.CharField(_("title"), max_length=50)
    price = models.FloatField(_("price"))
    discount_price = models.FloatField(_("discount price"))
    category = models.CharField(_("category"), max_length=50)
    description =  models.TextField(_("description"))
    image = models.ImageField(_("image"), upload_to='shop', blank=True , null=True)
    slug = models.SlugField(_("slug"), blank=True , null=True)

    

    class Meta:
        ordering = ('title',)
        verbose_name = _("Product")
        verbose_name_plural = _("Products")

    def save(self , *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        return super(Product , self).save(*args, **kwargs)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("Product_detail", kwargs={"pk": self.pk})



# checkout order models
class Order(models.Model):
    items = models.CharField(max_length=1000)
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    address = models.CharField(max_length=1000)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    zipcode = models.CharField(max_length=100)
    total = models.CharField(max_length=100)

    class Meta:
        verbose_name = "Order"


    def __str__(self):
        return str(self.name)