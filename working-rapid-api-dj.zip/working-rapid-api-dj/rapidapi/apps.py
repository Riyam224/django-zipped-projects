from django.apps import AppConfig


class RapidapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rapidapi'
