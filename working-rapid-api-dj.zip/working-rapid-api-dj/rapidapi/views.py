from django.core.exceptions import ImproperlyConfigured
from django.db.models import manager
from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from rest_framework import serializers
from rest_framework.views import APIView
from rest_framework.response import Response

from .serializers import StudentSerializer
from .models import Student


# def index(request):
#     return HttpResponse('hi')


class FirstView(APIView):
    
    def get(self , request,  *args, **kwargs):
        qs = Student.objects.all()
        serializer = StudentSerializer(qs , many=True)
        return Response(serializer.data)




class SecondView(APIView):
    
    def get(self , request,  *args, **kwargs):
        qs = Student.objects.all()
        serializer = StudentSerializer(qs , many=True)
        return Response(serializer.data)



