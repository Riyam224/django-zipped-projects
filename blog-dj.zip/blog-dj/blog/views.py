from django.shortcuts import render

# Create your views here.
from .models import Post
from django.http import HttpResponse , HttpResponseRedirect
from django.core.mail import send_mail
from django.conf import settings 
from django.contrib import messages

def index(request):
    posts = Post.objects.all()
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        number = request.POST['number']
        subject = request.POST['subject']
        message = request.POST['message']
      
        send_mail(
            name,
            message,
            settings.EMAIL_HOST_USER,
            [email]
        )
        messages.info(request , 'thanks for contacting me ')

    context = {
        'posts': posts,
        
    }
    return render(request , 'index.html' , context)