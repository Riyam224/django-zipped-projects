from django.urls import path
from . import views


urlpatterns = [
    path('' , views.jackets , name='jackets'),
    path('<int:pk>' , views.detail , name='detail'),
]
