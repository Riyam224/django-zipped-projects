from django.db import models

# Create your models here.
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse

class Jacket(models.Model):
    name = models.CharField(_("name"), max_length=50)
    brand = models.CharField(_("brand"), max_length=50)

    

    class Meta:
        verbose_name = _("Jacket")
        verbose_name_plural = _("Jackets")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("Jacket_detail", kwargs={"pk": self.pk})


class Jacket_detail(models.Model):
    color = models.CharField(_("color"), max_length=50)
    priceS = models.DecimalField(_("price small"), max_digits=5, decimal_places=2)
    priceM = models.DecimalField(_("price medium"), max_digits=5, decimal_places=2)
    priceL = models.DecimalField(_("price large"), max_digits=5, decimal_places=2)
    priceXL = models.DecimalField(_("price x-large"), max_digits=5, decimal_places=2)
    picture = models.URLField(_("picture"), blank=True , null=True)
    Jacket = models.ForeignKey(Jacket, related_name='jacket_detail', on_delete=models.CASCADE)
 
    
    class Meta:
        verbose_name = _("Jacket_detail")
        verbose_name_plural = _("Jacket_details")

    def __str__(self):
        return self.color

    def get_absolute_url(self):
        return reverse("Jacket_detail_detail", kwargs={"pk": self.pk})

