from django.contrib import admin

# Register your models here.
from .models import Jacket , Jacket_detail

admin.site.register(Jacket)
admin.site.register(Jacket_detail)