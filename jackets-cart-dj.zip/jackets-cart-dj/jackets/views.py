from django.shortcuts import get_object_or_404, render

# Create your views here.
from .models import Jacket , Jacket_detail


def jackets(request):
    jackets = Jacket.objects.all()
    context = {
        'jackets': jackets
    }
    return render(request , 'jackets.html', context)


def detail(request , pk):
    jacket = get_object_or_404(Jacket , id=pk)
    context  = {
        'jackets': jacket
    }
    return render(request , 'detail.html', context)